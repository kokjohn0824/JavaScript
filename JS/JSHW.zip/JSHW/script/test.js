



createNine(document.getElementById("Nine"));
climbAndPrint = (a) => {
    nodeHead = document.getElementById(a)

    let child = nodeHead.childNodes
    for (let i of child) {
        console.log(i.nodeType === 1 ? i.textContent : "--------")
    }
}
climbAndPrint("link1")



