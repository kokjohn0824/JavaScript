

main = () => {

    let cnie = new Nine(9, 9);
    let cf = new CheckForm();
    let st = new Stars();

    cnie.createNine("Nine");
    cf.addblur('name1', cf.checkName)
    cf.addblur('password1', cf.checkPassword)
    cf.addblur('date1', cf.checkDate)
    st.createStars("starbox")

}

//to load html ealier than js
init = () => {
    main();

}
try {
    document.addEventListener('DOMContentLoaded', init)
}
catch { }


